Assignment3 is the project folder;
tianshuohu is the database folder.
github: https://github.com/Hutsh/INFSCI2560/tree/master/Assignment3